ProofDataAI Demo Dataset

FILES
1. sales.csv
   - normal numerical analysis
   - missing amount
   - duplicate row
   - mixed INR/USD/EUR
   - dates
2. customers.csv
   - customer lookup/join
3. customer_master.csv
   - deliberate contradiction for customer_id 119
4. returns.csv
   - refunds
   - missing value
   - mixed currencies
5. inventory.csv
   - kg vs litre unit mismatch

JUDGE DEMO QUESTIONS

A. NORMAL VERIFIED QUESTION
Upload sales.csv
Question:
What is the maximum amount?
Expected:
60000
This demonstrates calculation + independent verification + proof.

B. DUPLICATE / DATA QUALITY
Upload sales.csv
Show:
- duplicate rows detected
- missing values detected

C. MIXED CURRENCY REFUSAL
Upload sales.csv
Question:
What is the total amount?
Expected behavior:
REFUSE because INR, USD and EUR are present and cannot be directly combined.

D. CONTRADICTION
Use customers.csv and customer_master.csv together.
Customer 119 is India in customers.csv but USA in customer_master.csv.
Expected behavior:
Contradiction warning / request for clarification.

E. AMBIGUOUS DATE
Question:
What were the sales on 02/03/2026?
Expected behavior:
Ask whether the date means 2 March or 3 February when the date format is ambiguous.

F. UNIT MISMATCH
Upload inventory.csv
Question:
What is the total quantity?
Expected behavior:
REFUSE or split by unit because kg and litre cannot be added directly.

G. SAFE NORMAL QUESTION
Question:
What is the minimum amount in INR?
Expected behavior:
Calculate only INR values and verify, if the app supports currency filtering.
